F - Go forward

B - Go backward

R - Go right

L - Go left

U - Go up

D - Go down

+ - current_cell += previous_cell; previous_cell = 0

# - current_cell = 1

~ - Inversion

, - Same as , in BF. Get n-th symbol in user input and put it in current cell

. - Print chr(current_cell_value)

@ - Print current cell's coordinates and its value

( and ) - Loop. Repeat while current cell has at least 1 neighbor that is not 0.

